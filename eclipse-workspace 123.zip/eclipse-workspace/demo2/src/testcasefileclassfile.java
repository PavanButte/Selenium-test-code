import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class testcasefileclassfile {
WebDriver driver;
	
	
@Test(groups = {"sanity","regression"},priority = 1)
public void launchBrowser() {
System.setProperty("webdriver.chrome.driver","C:/Users/pavan/OneDrive/Desktop/chromedriver.exe");
driver = new ChromeDriver();
driver.manage().window().maximize();
     }  
@Test(groups = {"sanity","regression"},priority = 7)
public void closeBrowser(){
driver.close();
}

@Test(groups = {"sanity","regression"},priority = 2)
public void verifyHdfctitle() {
driver.get("https://netbanking.hdfcbank.com/netbanking/");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Welcome to HDFC Bank NetBanking");
}

@Test(groups = {"sanity","regression"},priority = 3)
public void verifyIcicititle() {
driver.get("https://www.icicibank.com/?ITM=nli_cms_LOGIN_revamp_personal_topnavigation");
String page = driver.getTitle();
Assert.assertEquals(page,"Personal Banking & Netbanking Services Online - ICICI Bank");
}

@Test(groups = {"sanity","regression"},priority = 4)
public void verifytitle() {
driver.get("https://www.google.co.in/");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Google");
}

@Test(groups = {"sanity","regression"},priority = 5)
public void verifynokiatitle() {
driver.get("https://www.nokia.com/");
String page = driver.getTitle();
Assert.assertEquals(page,"Nokia Corporation");
}

@Test(groups = {"sanity","regression"},priority = 5)
public void verifyjiotitle() {
driver.get("https://www.jio.com/selfcare/login");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Login | Jio");
   }
 }

















