package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementLocators {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	driver.get("https://www.gmail.com");
    driver.manage().window().maximize();
    WebElement editbox = driver.findElement(By.id("identifier Id"));
    editbox.sendKeys("india123");
    String val = editbox.getAttribute("value");
    System.out.println("val");
    editbox.clear();
	}

}
