package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class APICOMMANDS {

	public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	driver.manage().window().maximize();
	//driver.get("https://www.icicibank.com/");
	//getcurrenturl()
	//String browserurl = driver.getCurrentUrl();
	//System.out.println("browserurl");
	
	//gettitle()
	//String browsertitle = driver.getTitle();
	//System.out.println("browsertitle");
	
	//get()
	//driver.get("https://www.icicibank.com/");
	
	//Navigate().to()
	//driver.get("https://www.google.co.in/");
	//String browserurl = driver.getCurrentUrl();
	//System.out.println("browserurl");
	//driver.navigate().to("https://www.eclipse.org/");
	//browserurl = driver.getCurrentUrl();
	//System.out.println("browserurl");
	
	//Navigate().Back()
	//driver.get("https://www.google.co.in/");
	//String browserurl = driver.getCurrentUrl();
	//System.out.println("browserurl");
	//driver.navigate().to("https://www.eclipse.org/");
	//browserurl = driver.getCurrentUrl();
	//System.out.println("browserurl");
	//driver.navigate().back();
	//browserurl = driver.getCurrentUrl();
	//System.out.println("browserurl");
	
	//Navigate().Forword()
	//driver.get("https://www.google.co.in/");
	//System.out.println("driver.getcurrenturl");
	//driver.navigate().to("https://www.youtube.com/");
	//System.out.println("driver.getcurrenturl");
	//driver.navigate().back();
	//System.out.println("driver.getcurrenturl");
	//driver.navigate().forward();
	//System.out.println("driver.getcurrenturl");
	
	//IsDisplay()
	//driver.get("https://www.google.co.in/");
	//boolean linkpresent = driver.findElement(By.linkText("Gmail")).isDisplayed();
	//System.out.println("linkpresent");
	//driver.close();
	
	//IsEnabled()
	//driver.get("https://www.google.co.in/");
	//boolean linkpresent = driver.findElement(By.linkText("Gmail")).isEnabled();
	//System.out.println("linkpresent");
	
	//ISSelected()
	driver.get("https://www.facebook.com/signup");
	Thread.sleep(3000);
	WebElement Custom = driver.findElement(By.id("u_0_o_Y6"));
	boolean radiobuttonstatus = Custom.isSelected();
	System.out.println("RadioButtonStatus");
	Custom.click();
	Thread.sleep(3000);
	radiobuttonstatus = Custom.isSelected();
	System.out.println("RadioButtonStatus");
	WebElement checkBox = driver.findElement(By.name("NewSeletter"));
	Thread.sleep(3000);
	checkBox.click();
	System.out.println("checkBox is Selected");
	checkBox.click();
	System.out.println("checkBox is Selected");
	
	}

}
