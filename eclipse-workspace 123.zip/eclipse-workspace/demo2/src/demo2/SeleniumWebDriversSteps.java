package demo2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumWebDriversSteps {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
    //Create Browser Driver/Lunch Chrome Browser Window With Blank URL
	WebDriver driver = new ChromeDriver();
	
	// Maximize
	driver.manage().window().maximize();
	
	//Navigate to a Specified URL
	driver.get("https://www.google.co.in/");
	
	//Navigate To another URL
	driver.navigate().to("https://www.google.co.in/");
	
	//Back to Previous URL
	driver.navigate().back();
	
	//forword
	driver.navigate().forward();
	
	//Refresh The Browser Window
	driver.navigate().refresh();
	
	//Return Browser URL
	String url = driver.getCurrentUrl();
	System.out.println("url");
	
	//Return Browser Title
	String title = driver.getTitle();
	System.out.println("title");
	
	//returl browser window handle
	String handle = driver.getWindowHandle();
	System.out.println("handle");
	
	//Return Page Source
	String Pagesource = driver.getPageSource();
	System.out.println("Pagesource");
	
	//Close the focused Browser Window
	driver.close();
	
	}

}
