package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingEditBox {

	public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.facebook.com/");
	Boolean displaystatus = driver.findElement(By.id("username")).isDisplayed();
	System.out.println("enabledstates");
	String uname = "Pavan";
	driver.findElement(By.name("username")).sendKeys("uname");
	Thread.sleep(3000);
	String val = driver.findElement(By.name("username")).getAttribute("value");
	System.out.println("val");
	String elementvaluetype = driver.findElement(By.name("username")).getAttribute("type");
	System.out.println("val");
	elementvaluetype = driver.findElement(By.name("Password")).getAttribute("type");
	System.out.println("elementvaluetype");
	Thread.sleep(3000);
	driver.findElement(By.name("username")).clear();
	
	}

}
