package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ManualActions {

	    public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
			
		driver.get("http://gmail.com");
		driver.manage().window().maximize();
		
		Boolean linkpresent = driver.findElement(By.linkText("Gmail")).isDisplayed();
		System.out.println("linkpresent");//true
		
		Boolean linkstatus = driver.findElement(By.linkText("Gmail")).isEnabled();
		System.out.println("linkstatus");//true
		
		String linkname = driver.findElement(By.linkText("Gmail")).getText();
		System.out.println("linkname");
		Thread.sleep(3000);
		
		driver.findElement(By.linkText("Gmail")).click();
		driver.close();
		
		//handling Button
		/*Boolean status = driver.findElement(By.id("identfiernext")).isDisplayed();
		System.out.println(status);
		status = driver.findElement(By.id("identfiernext")).isEnabled();
        System.out.println("status");
		driver.findElement(By.id("identfiernext")).click();*/
		
		

	}

}
