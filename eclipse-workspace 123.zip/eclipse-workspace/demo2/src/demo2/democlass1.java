package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class democlass1 {

	public static void main(String[] args) {
    System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
    WebDriver driver = new ChromeDriver();
    
    driver.get("https://www.fb.com");
    driver.manage().window().maximize();
    driver.findElement(By.id("identfierid")).sendKeys("india123");
	}
}
