package demo2;

import javax.swing.Popup;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ErrorMsgPopupWindow {

	public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
		
	//driver.get("https://www.gmail.com");
	driver.manage().window().maximize();
	
	//Return Test Area
	//String testarea = driver.findElement(By.id("identifierId")).getText();
	//System.out.println("testarea");
	
	//Return Error Message
	//WebElement errormessage = driver.findElement(By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div/div[2]/div[2]/div"));
	//System.out.println("errormessage");
	
	//Handle Popup Window
	driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
	driver.findElement(By.name("Pavan")).click();
	
	Alert popup = driver.switchTo().alert();//switch Driver focus from web page to popup window.
	String errormessage1 = popup.getText();
	Thread.sleep(3000);
	System.out.println("errormessage");
	popup.accept();
	driver.findElement(By.id("login")).sendKeys("india123");
	driver.close();
	
	}

}
