package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class seleniumtestcase1 {

	public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	driver.manage().window().maximize();
	
	driver.findElement(By.id("create account")).click();
	Thread.sleep(3000);
	String url1 = driver.getCurrentUrl();
	System.out.println("url1");
	
	if(url1.contains("wikipedia.org")) {
	System.out.println("1st verification : "+" it is an internal link-passes");
	}
	else
	{
	System.out.println("1st verification : "+" it is an internal link-failed");
	}
	driver.navigate().back();
	driver.findElement(By.partialLinkText("seleniumhq")).click();
	Thread.sleep(3000);
	
	String url2 = driver.getCurrentUrl();
	System.out.println("url2");
	
	if(!url2.contains("wikipedia.org")) {
	System.out.println("2st verification : "+" it is an internal link-passes");
	}
	else
	{
	System.out.println("2st verification : "+" it is an internal link-failed");
	}
	driver.close();
	
	}

}
