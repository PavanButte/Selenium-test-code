package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class testcase3vrpoint {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.irctc.co.in/nget/train-search");
	driver.manage().window().maximize();
    driver.findElement(By.linkText("Login")).click();
    driver.findElement(By.linkText("New to Flipkart? Create an account")).click();
    driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[6]/a")).click();
    driver.findElement(By.name("name4b57da34")).sendKeys("ABCD");
    driver.findElement(By.name("Choose a Rediffmail ID")).sendKeys("pavan@gmail.com");
    driver.findElement(By.id("//*[@id=\"tblcrtac\"]/tbody/tr[7]/td[3]/input[2]")).click();
    driver.findElement(By.name("Password")).sendKeys("A@123");
    driver.findElement(By.name("Retype password")).sendKeys("A@123");
    
    
    
	}

}
