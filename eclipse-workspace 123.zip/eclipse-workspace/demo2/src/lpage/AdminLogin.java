package lpage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AdminLogin {

public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
WebDriver driver = new ChromeDriver();  
driver.manage().window().maximize();

LoginPage pavan = new LoginPage(driver);
driver.get("https://ashokitech.com/");
pavan.Typeusername("pavanbutte2@gmail.com");
pavan.Typepassword("Pavan@123");
pavan.ClickLoginbutton();
String url = driver
	}
}
