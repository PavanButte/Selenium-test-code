package lpage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ErrorMessage {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();  
		driver.manage().window().maximize();

		LoginPage pavan = new LoginPage();
		driver.get("https://ashokitech.com/");
		pavan.Typeusername("pavanbutte2@gmail.com");
		pavan.Typepassword("Pavan@123");
		pavan.ClickLoginbutton();
		String url = pavan.captureErrormessage();
		if(url.contains("error = Involid administrator login attempt")) {
			System.out.println("Login unsuccessful and showing correct error message - passed");
		}
		else {
			System.out.println("Login unsuccessful and not showing correct error message - falied");
		}
		driver.close();
			}
		}


	

