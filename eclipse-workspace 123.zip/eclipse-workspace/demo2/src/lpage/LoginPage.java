package lpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import net.bytebuddy.asm.Advice.Return;

public class LoginPage {
WebDriver lpage;

//create web element using Element Locators
By user = By.name("username");
By pwd = By.name("Password");
By LoginButton = By.id("LOG IN");
By ErrorMessage = By.className("MessagestackError");
By cataloglink =By.linkText("Online Catalog");

public void Loginpage(WebDriver abcd2) {
this.lpage = abcd2;
}

//create customized commands
public void Typeusername(String uname) {
lpage.findElement(user).sendKeys(uname);
}

public void Typepassword(String password) {
lpage.findElement(pwd).sendKeys(password);
}


public void ClickLoginbutton () {
lpage.findElement(LoginButton).click();
}

public String captureErrormessage() {
String Message =lpage.findElement(ErrorMessage).getText();	
return Message;
}

public void ClickLinl() {
lpage.findElement(cataloglink).click();
}
}