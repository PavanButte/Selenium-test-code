package TestNGProgs;
import org.testng.Assert;
import org.testng.annotations.Test;

public class class1 extends classp {

@Test (priority = 3)
public void verifytitle() {
driver.get("https://www.google.co.in/");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Google");
}

@Test (priority = 1)
public void verifynokiatitle() {
driver.get("https://www.nokia.com/");
String page = driver.getTitle();
Assert.assertEquals(page,"Nokia Corporation");
}

@Test (priority = 2)
public void verifyjiotitle() {
driver.get("https://www.jio.com/selfcare/login");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Login | Jio");
   }
}
