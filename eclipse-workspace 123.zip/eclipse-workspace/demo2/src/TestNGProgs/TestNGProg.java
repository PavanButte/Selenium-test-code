package TestNGProgs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNGProg {
WebDriver driver;
	
@Test
public void verifytitle() {
System.setProperty("webdriver.chrome.driver","C:/Users/pavan/OneDrive/Desktop/chromedriver.exe");
driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get("https://www.google.co.in/");
String pagetitle = driver.getTitle();

Assert.assertEquals(pagetitle,"google");

/*if(pagetitle.equals("Google")) {
System.out.println("Google Application was Lanched -Passed");
}
else {
System.out.println("Google Application was Not Lanched -Failed");*/
driver.close();
  }
}


