package TestNGProgs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestNGprog0 {
static WebDriver driver;

public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","C:\\Users\\pavan\\OneDrive\\Desktop\\chromedriver.exe");
driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get("https://www.google.co.in/");
String pagetitle = driver.getTitle();

if(pagetitle.equals("Google")) {
System.out.println("Google Application was Lanched -Passed");
}
else {
System.out.println("Google Application was Not Lanched -Failed");
    }
   }
}
