package TestNGProgs;
import org.testng.Assert;
import org.testng.annotations.Test;

public class class2 extends classp {

@Test (priority = 5)
public void verifyHdfctitle() {
driver.get("https://netbanking.hdfcbank.com/netbanking/");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Welcome to HDFC Bank NetBanking");
}

@Test (priority = 4)
public void verifyIcicititle() {
driver.get("https://www.icicibank.com/?ITM=nli_cms_LOGIN_revamp_personal_topnavigation");
String page = driver.getTitle();
Assert.assertEquals(page,"Personal Banking & Netbanking Services Online - ICICI Bank");
}
}
