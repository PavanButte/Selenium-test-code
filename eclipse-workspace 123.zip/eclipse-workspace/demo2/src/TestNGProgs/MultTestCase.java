package TestNGProgs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MultTestCase {
WebDriver driver;

@Test (priority = 1)
public void LaunchBrowser() {
System.setProperty("webdriver.chrome.driver","C:/Users/pavan/OneDrive/Desktop/chromedriver.exe");
driver = new ChromeDriver();
driver.manage().window().maximize();
}

@Test (priority = 2)
public void verifytitle() {
driver.get("https://www.google.co.in/");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Google");
}
@Test (priority = 3)
public void CloseBrowser(){
driver.close();

}
}





