package TestNGProgs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestPriority {
WebDriver driver;

@Test (priority = 1)
public void LaunchBrowser() {
System.setProperty("webdriver.chrome.driver","C:/Users/pavan/OneDrive/Desktop/chromedriver.exe");
driver = new ChromeDriver();
driver.manage().window().maximize();
}
@Test (priority = 5)
public void CloseBrowser() {
	driver.close();
}

@Test (priority = 2)
public void verifytitle() {
driver.get("https://www.google.co.in/");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Google");
}

@Test (priority = 4)
public void verifynokiatitle() {
driver.get("https://www.nokia.com/");
String page = driver.getTitle();
Assert.assertEquals(page,"Nokia Corporation");
}

@Test (priority = 3)
public void verifyjiotitle() {
driver.get("https://www.jio.com/selfcare/login");
String pagetitle = driver.getTitle();
Assert.assertEquals(pagetitle,"Login | Jio");
}

}
